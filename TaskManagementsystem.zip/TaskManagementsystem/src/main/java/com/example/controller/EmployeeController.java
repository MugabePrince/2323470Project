package com.example.controller;

import com.example.model.Employee;
import com.example.model.Task;
import com.example.serviceImplementation.EmployeeServiceImplementation;
import com.example.serviceImplementation.TaskServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class EmployeeController {
    @Autowired
    EmployeeServiceImplementation service;
    TaskServiceImplementation taskService;


    @GetMapping("/employee/new")
    public String getEmployeePage(Model model){
        Employee employee = new Employee();
        List<Task> listTask = taskService.displayTasks();
        model.addAttribute("tasks",listTask);
        model.addAttribute("employee", employee);
        model.addAttribute("pageTitle", "Create your Task");
        return "employeeForm";
    }

    @PostMapping("/employee/save")
    public String saveEmployee(Model model, Employee employee, RedirectAttributes ra){
        Employee savedEmployee = service.saveEmployee(employee);
        model.addAttribute("employee",savedEmployee);
        ra.addFlashAttribute("message","Saved successfully");


        return "redirect:/employee/new";
    }

    @GetMapping("/employee/list")
    public String displayEmployees(Model model){
        List<Employee> listEmployee = service.displayEmployee();
        model.addAttribute("listEmployee", listEmployee);
        return "employeeCrud";
    }

@GetMapping("/employee/edit/{employeeId}")
public String editEmployee(@PathVariable("employeeId") Employee employeeId, Model model, RedirectAttributes ra){
    try {
        Employee saveEmployee = service.findEmployeeBYId(employeeId);
        model.addAttribute("employee", saveEmployee);
        model.addAttribute("pageTitle","edit employee");
        ra.addFlashAttribute("message", "Employee updated successfully");
        return "employeeForm";
    }catch (Exception ex){
        ex.printStackTrace();
    }

    return "redirect:/employee/list";
}

    @GetMapping("/employee/delete/{id}")
    public String deleteEmployee(@PathVariable("id") Employee id,Model model, RedirectAttributes ra){
        service.deleteEmployee(id);
        ra.addFlashAttribute("message","Employee deleted successfully");

        return "redirect:/employee/list";
    }

}
