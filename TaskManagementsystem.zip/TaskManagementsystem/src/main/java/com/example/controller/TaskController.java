package com.example.controller;

import com.example.model.Task;
import com.example.serviceImplementation.TaskServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class TaskController {
    @Autowired
    TaskServiceImplementation service;

    @GetMapping("/task/new")
    public String showRequestForm(Model model){
        Task task = new Task();
        model.addAttribute("task", task);
        model.addAttribute("pageTitle", "Create New task");

        return "taskForm";
    }
    @PostMapping("/task/save")
    public String saveRequest(Task request, Model model, RedirectAttributes ra){
        try {
            Task savedRequest = service.saveTask(request);
            model.addAttribute("request", savedRequest);
            ra.addFlashAttribute("message", "New Task saved successfully");

        }catch (Exception ex){
            ex.printStackTrace();
        }
        return "redirect:/task/list";
    }
    @GetMapping("/task/list")
    public String displayTasks(Model model){
        List<Task> listTasks = service.displayTasks();
        model.addAttribute("listTask", listTasks);

        return "taskcrudd";
    }

    @GetMapping("/task/edit/{taskId}")
    public String editTask(@PathVariable("taskId") Task taskId, Model model, RedirectAttributes ra){
        try {
            Task savedTask = service.findTaskById(taskId);
            model.addAttribute("task", savedTask);
            model.addAttribute("pageTitle","edit task");
            ra.addFlashAttribute("message", "Your task updated successfully");
            return "taskForm";
        }catch (Exception ex){
            ex.printStackTrace();
        }

        return "redirect:/task/list";
    }

    @GetMapping("/task/delete/{taskId}")
    public String deleteTask(@PathVariable("taskId") Task task, Model model, RedirectAttributes ra){
        try{
            service.deleteTask(task);
            ra.addFlashAttribute("message", "task successfully deleted");
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return "redirect:/task/list";
    }

}
