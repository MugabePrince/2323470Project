package com.example.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "Employee_Tble")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data

public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String firstname;
    private String secondname;
    private String phone;
    private String Taskname;

}
