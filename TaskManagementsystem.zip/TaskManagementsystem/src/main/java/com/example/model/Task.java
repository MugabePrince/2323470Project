package com.example.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Task_Tbl")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Task {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  int id;
    @Id
    private String taskId;
    private String taskName;
    private String taskDescription;
    private String assignedTo;
    private String phone;
}