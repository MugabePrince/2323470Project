package com.example.service;

import com.example.model.Employee;

import java.util.List;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);
    List<Employee> displayEmployee();
    Employee findEmployeeBYId(Employee employee);
    //Employee updateEmployees(Employee employee);
    Employee editEmployee(Employee employee);
    void deleteEmployee(Employee employee);
}
