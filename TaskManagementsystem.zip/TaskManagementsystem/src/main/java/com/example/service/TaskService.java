package com.example.service;

import com.example.model.Task;

import java.util.List;

public interface TaskService {
    Task saveTask(Task task);
    List<Task> displayTasks();
    Task findTaskById(Task task);
    //Task updateTask(Task task);
    void deleteTask(Task task);

    Task updateTask(Task task);
}
