package com.example.serviceImplementation;

import com.example.model.Employee;
import com.example.repository.EmployeeRepository;
import com.example.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeServiceImplementation implements EmployeeService {
    @Autowired
    EmployeeRepository repo;
    @Override
    public Employee saveEmployee(Employee employee) {
        return repo.save(employee);
    }

    @Override
    public List<Employee> displayEmployee() {
        return repo.findAll();
    }

    @Override
    public Employee findEmployeeBYId(Employee employee) {
        return repo.findById(employee.getId()).orElse(null);
    }

    @Override
    public Employee editEmployee(Employee employee) {
        Employee savedEmployee =  repo.findById(employee.getId()).orElse(null);
        if (savedEmployee!=null){
            savedEmployee.setPhone(employee.getPhone());
            savedEmployee.setFirstname(employee.getFirstname());
            savedEmployee.setSecondname(employee.getSecondname());
            savedEmployee.setTaskname(employee.getTaskname());

            return repo.save(savedEmployee);
        }
        return repo.save(employee);
    }

    @Override
    public void deleteEmployee(Employee employee) {
        Employee savedEmployee =  repo.findById(employee.getId()).orElse(null);
        if (savedEmployee!=null){
            repo.delete(savedEmployee);
        }

    }
}
