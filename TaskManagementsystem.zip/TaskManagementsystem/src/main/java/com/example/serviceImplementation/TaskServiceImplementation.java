package com.example.serviceImplementation;

import com.example.model.Task;
import com.example.repository.TaskRepository;
import com.example.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TaskServiceImplementation implements TaskService {
    @Autowired
    TaskRepository repo;
    @Override
    public Task saveTask(Task task) {
        return repo.save(task);
    }

    @Override
    public List<Task> displayTasks() {
        return repo.findAll();
    }

    @Override
    public Task findTaskById(Task task) {
        return repo .findById(task.getTaskId()).orElse(null);
    }

    @Override
    public Task updateTask(Task task) {
        Task savedTask = repo.findById(task.getTaskId()).orElse(null);
        if (savedTask != null) {
            savedTask.setTaskName(task.getTaskName());
            savedTask.setTaskDescription(task.getTaskDescription());
            savedTask.setTaskName(task.getTaskName());
            savedTask.setPhone(task.getPhone());
            return repo.save(savedTask);
        }
        else {
            return repo.save(task);
        }

    }

    @Override
    public void deleteTask(Task task) {
        Task savedTask = repo.findById(task.getTaskId()).orElse(null);
        if (savedTask != null) {
            repo.delete(savedTask);
        }

    }
}
